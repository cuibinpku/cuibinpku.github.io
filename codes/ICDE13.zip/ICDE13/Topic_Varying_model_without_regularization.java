package model.Fashion.TopicVarying;

import java.util.ArrayList;
import java.util.HashMap;

import model.Fashion.TopicSharing.Topic_Sharing_model;

import basic.Item;
import basic.matrix_function;

public class Topic_Varying_model_without_regularization  extends Topic_Sharing_model
{
	public int context_number_of_topics;
	public double[][] keywords_given_context_topics;
	public double[][]keywords_given_context_topics_next;
	
	public Topic_Varying_model_without_regularization ()
	{
		
	}
	public Topic_Varying_model_without_regularization (int number_of_keywords,int number_of_documents,int number_of_topics, int number_of_timeslices,int context_number_of_topics,HashMap<Integer,ArrayList<Item>> user_item_graph,double lamda,double gama)
	{
		super( number_of_keywords,number_of_documents, number_of_topics,  number_of_timeslices,user_item_graph,lamda,gama);
		this.context_number_of_topics=context_number_of_topics;
		
	}
	
	
	public void initialize()
	{
		//randomize and normalize the initial matrix
		keywords_given_topics=new double[number_of_keywords][number_of_topics];
		topics_given_documents=new double[number_of_topics][number_of_documents];
		topics_given_timeslice=new double[context_number_of_topics][number_of_timeslices];
		keywords_given_context_topics=new double[number_of_keywords][context_number_of_topics];
		                                                                   
		                                                                   
		keywords_given_topics_next=new double[number_of_keywords][number_of_topics];
		topics_given_documents_next=new double[number_of_topics][number_of_documents];
		topics_given_timeslice_next=new double[context_number_of_topics][number_of_timeslices];
		keywords_given_context_topics_next=new double[number_of_keywords][context_number_of_topics];
		
		matrix_function.random_and_normalize(topics_given_documents);
		matrix_function.random_and_normalize(topics_given_timeslice);
		matrix_function.random_and_normalize(keywords_given_topics);
		matrix_function.random_and_normalize(keywords_given_context_topics);
		//initialize_temporal();
		initialize_lambda();
	}	
	
	public void normalize_and_copy()
	{
		matrix_function.normalize_smooth(topics_given_documents_next);
		matrix_function.normalize_smooth(keywords_given_topics_next);
		matrix_function.normalize_smooth(topics_given_timeslice_next);
		matrix_function.normalize_smooth(keywords_given_context_topics_next);
		
		
		matrix_function.copy(topics_given_documents, topics_given_documents_next);
		matrix_function.copy(keywords_given_topics, keywords_given_topics_next);
		matrix_function.copy(topics_given_timeslice, topics_given_timeslice_next);
		matrix_function.copy(keywords_given_context_topics, keywords_given_context_topics_next);
		matrix_function.copy(lambda_temporal,lambda_temporal_next);
	
		
		
	}
	
	public void assign_zero()
	{
		matrix_function.assign_zero(topics_given_documents_next);
		matrix_function.assign_zero(keywords_given_topics_next);
		matrix_function.assign_zero(topics_given_timeslice_next);
		matrix_function.assign_zero(keywords_given_context_topics_next);
		
		matrix_function.assign_zero(estimate_lambda_temporal);
		matrix_function.assign_zero(estimate_lambda_stable);
	}
	
	
	//using linked list to implement sparse matrix
	public void E_M_step(int iteration)
	{
		
		
		if(iteration!=0)
		{  
			matrix_function.normalize_smooth(topics_given_documents_next);
			matrix_function.normalize_smooth(topics_given_timeslice_next);
			matrix_function.normalize_smooth(keywords_given_topics_next);
			matrix_function.normalize_smooth(keywords_given_context_topics_next);
			estimate_lambda_next();
			
			if(lamda>0)
			{
			double pre_max=compute_objective_function(topics_given_timeslice,keywords_given_topics,topics_given_documents,lambda_temporal,keywords_given_context_topics,2);
			refine_M_step(pre_max,2);
			}
			else
			{
				normalize_and_copy(); 
			}
		}
		assign_zero();
		for(int i_d:user_item_graph.keySet())
		{
			for(Item it:user_item_graph.get(i_d))
			{    
				int i_k=it.item_id;
				//the timestamp of document
				int i_t = it.slice_id;
				int num=it.number;
				if(i_t>=0)
				{
				double denominator=0;
				double postier_topics[]=new double[number_of_topics];
				double temporal_postier_topics[]=new double[context_number_of_topics];
				for(int i_z=0;i_z<number_of_topics;i_z++)
				{
					postier_topics[i_z]=
						(1-lambda_temporal[i_d])*
						topics_given_documents[i_z][i_d]*
						keywords_given_topics[i_k][i_z];
					denominator+=postier_topics[i_z];
					
					
				}
				
				for(int i_z=0;i_z<context_number_of_topics;i_z++)
				{
					
					
					temporal_postier_topics[i_z]=
						lambda_temporal[i_d]*
						topics_given_timeslice[i_z][i_t]*keywords_given_context_topics[i_k][i_z];
					
					denominator+=temporal_postier_topics[i_z];
				}
				
				
				for(int i_z=0;i_z<number_of_topics;i_z++)
				{
					if(denominator==0){
						postier_topics[i_z]=0;
						//temporal_postier_topics[i_z]=0;
					}
					else{
						postier_topics[i_z]/=denominator;
						//temporal_postier_topics[i_z]/=denominator;
					}
				}
				
				for(int i_z=0;i_z<context_number_of_topics;i_z++)
				{
					if(denominator==0){
						//postier_topics[i_z]=0;
						temporal_postier_topics[i_z]=0;
					}
					else{
						//postier_topics[i_z]/=denominator;
						temporal_postier_topics[i_z]/=denominator;
					}
				}
				part_M_step(postier_topics, temporal_postier_topics,i_d,i_k,num,i_t);
			}
		}
			
		
		}
	}
	
	
	
	public void part_M_step(double postier_topics[],double temporal_postier_topics[],int i_d,int i_k,int num,int i_t)
	{  
		//int i_t = timestamp_of_keywords_documents[i_k][i_d];
		if(i_t>=0)
		{
		for(int i_z=0;i_z<number_of_topics;i_z++)
		{
			double estimate_tkd=num*
			postier_topics[i_z];
			
			topics_given_documents_next[i_z][i_d]+=estimate_tkd;
			keywords_given_topics_next[i_k][i_z]+=estimate_tkd;
			estimate_lambda_stable[i_d]+=estimate_tkd;
			
			
			
		}for(int i_z=0;i_z<context_number_of_topics;i_z++)
		{
			
			
			
			double estimate_bkd=num*
			temporal_postier_topics[i_z];
			
			topics_given_timeslice_next[i_z][i_t]+=estimate_bkd;
			keywords_given_context_topics_next[i_k][i_z]+=estimate_bkd;
			estimate_lambda_temporal[i_d]+=estimate_bkd;
		}
		
		
		}	
	
	}
	
	public void refine_M_step(double pre_max,int selection)
	{
	  double[][] topics_given_timeslice1=new double[context_number_of_topics][number_of_timeslices];
	  double[][] topics_given_timeslice2=new double[context_number_of_topics][number_of_timeslices];
	  
	  matrix_function.copy(topics_given_timeslice1, topics_given_timeslice_next);
	  
	  
	  
	  for(int i_t=0;i_t<number_of_timeslices;i_t++)
	  { 
		  for(int i_z=0;i_z<context_number_of_topics;i_z++)
		  {   if(i_t==0)
		      {
			  topics_given_timeslice2[i_z][i_t]=topics_given_timeslice_next[i_z][i_t];
		     }
		    else
			  topics_given_timeslice2[i_z][i_t]=(1-gama)*  topics_given_timeslice_next[i_z][i_t]+gama*topics_given_timeslice_next[i_z][i_t-1];
		  }
		  
	  }
	  matrix_function.normalize_smooth(topics_given_timeslice2);
	  
	  double count=0;
	  double t2=compute_objective_function(topics_given_timeslice2,keywords_given_topics_next,topics_given_documents_next,lambda_temporal_next,keywords_given_context_topics_next,selection);
	  double t1=compute_objective_function(topics_given_timeslice1,keywords_given_topics_next,topics_given_documents_next,lambda_temporal_next,keywords_given_context_topics_next,selection);
	  while(t2>=t1)
	  {   
		   if(t2==t1)
		   {
			   count++;
			   if(count>6)
			   {   
				   count=0;
				   break;
			   }
		   }
		  
		  matrix_function.copy(topics_given_timeslice1, topics_given_timeslice2);
		  
		  if(compute_objective_function(topics_given_timeslice1,keywords_given_topics_next,topics_given_documents_next,lambda_temporal_next,keywords_given_context_topics_next,selection)>pre_max)
		  {
			break;  
		  }
		  
		  for(int i_t=0;i_t<number_of_timeslices;i_t++)
		  { 
			  for(int i_z=0;i_z<context_number_of_topics;i_z++)
			  {   
				  if(i_t==0)
					  topics_given_timeslice2[i_z][i_t]=topics_given_timeslice1[i_z][i_t];
				  else
				  topics_given_timeslice2[i_z][i_t]=(1-gama)*  topics_given_timeslice1[i_z][i_t]+gama*topics_given_timeslice1[i_z][i_t-1];
			  }
			  
		  }
		  matrix_function.normalize_smooth(topics_given_timeslice2);
		  
		  t2=compute_objective_function(topics_given_timeslice2,keywords_given_topics_next,topics_given_documents_next,lambda_temporal_next,keywords_given_context_topics_next,selection);
		  t1=compute_objective_function(topics_given_timeslice1,keywords_given_topics_next,topics_given_documents_next,lambda_temporal_next,keywords_given_context_topics_next,selection);
		  
	  }
	  
	  
	  
	  if(compute_objective_function(topics_given_timeslice1,keywords_given_topics_next,topics_given_documents_next,lambda_temporal_next,keywords_given_context_topics_next,selection)>=pre_max)
	  {  
		  matrix_function.copy(topics_given_timeslice_next, topics_given_timeslice1);
		  normalize_and_copy();  
		  
	  }
	  
	}
	
	
	public double compute_objective_function(double topics_given_timeslice[][],double keywords_given_topics[][],double topics_given_documents[][],double lambda_temporal[],double[][] keywords_given_context_topics, int selection)
	{
		 if(selection==1)
		   return compute_objective(topics_given_timeslice,keywords_given_topics,topics_given_documents,lambda_temporal,keywords_given_context_topics)-lamda*compute_regularization(topics_given_timeslice);
		 else
		 {
			 return compute_objective2(topics_given_timeslice,keywords_given_topics,topics_given_documents,lambda_temporal,keywords_given_context_topics)-lamda*compute_regularization(topics_given_timeslice); 
		 }
	}
	
	private double compute_objective(double topics_given_timeslice[][],double keywords_given_topics[][],double topics_given_documents[][],double lambda_temporal[],double[][] keywords_given_context_topics)
	{  
		double sum=0;
		for(int i_d:user_item_graph.keySet())
		{
			for(Item it:user_item_graph.get(i_d))
			{  
				int i_k=it.item_id;
				int t=it.slice_id;
			   double temp=0;
			   for(int i_z=0;i_z<number_of_topics;i_z++)
			   {
				   temp+=it.interest_topic[i_z]*Math.log((1-lambda_temporal[i_d])*topics_given_documents[i_z][i_d]*keywords_given_topics[i_k][i_z]);
				   //temp+=it.fashion_topic[i_z]*Math.log((lambda_temporal[i_d])*topics_given_timeslice[i_z][t]*keywords_given_topics[i_k][i_z]);  		   
			   
			   }
			   for(int i_z=0;i_z<context_number_of_topics;i_z++)
			   {
				   //temp+=it.interest_topic[i_z]*Math.log((1-lambda_temporal[i_d])*topics_given_documents[i_z][i_d]*keywords_given_topics[i_k][i_z]);
				   temp+=it.fashion_topic[i_z]*Math.log((lambda_temporal[i_d])*topics_given_timeslice[i_z][t]*keywords_given_context_topics[i_k][i_z]);  		   
			   
			   }
			   sum=sum+it.number*temp;
			}	
			
		}
		
		return sum;
	}
	// reduce storage space, but need to recompute the topics_given_documents_keyword[][][];
	private double compute_objective2(double topics_given_timeslice2[][],double keywords_given_topics2[][],double topics_given_documents2[][],double lambda_temporal2[],double[][] keywords_given_context_topics2)
	{  
		double sum=0;
		for(int i_d:user_item_graph.keySet())
		{
			for(Item it:user_item_graph.get(i_d))
			{  
				int i_k=it.item_id;
				int i_t=it.slice_id;
			   double[] temp=new double[number_of_topics];
			   double[] temp1=new double[context_number_of_topics];
			   double denominator=0;
			   for(int i_z=0;i_z<number_of_topics;i_z++)
				{   
					//double temp=0;
					temp[i_z]=(1-lambda_temporal[i_d])*
					topics_given_documents[i_z][i_d]*
					keywords_given_topics[i_k][i_z];
					
					//temp1[i_z]=temp;
					denominator+=temp[i_z];
					
				}

			   for(int i_z=0;i_z<context_number_of_topics;i_z++)
				{   
				   temp1[i_z]=lambda_temporal[i_d]*
					topics_given_timeslice[i_z][i_t]*keywords_given_context_topics[i_k][i_z];
					
					
					denominator+=temp1[i_z];
				}

			   
			   
			   
				for(int i_z=0;i_z<number_of_topics;i_z++)
				{
					if(denominator==0) {
						temp[i_z]=0;
						//temp1[i_z]=0;
						
					}
					else {
						
						temp[i_z]/=denominator;
						//temp1[i_z]/=denominator;
					}
				}
			   
				for(int i_z=0;i_z<context_number_of_topics;i_z++)
				{
					if(denominator==0) {
						//temp[i_z]=0;
						temp1[i_z]=0;
						
					}
					else {
						
						//temp[i_z]/=denominator;
						temp1[i_z]/=denominator;
					}
				}
			   
			   double temp3=0;
			   
			   for(int i_z=0;i_z<number_of_topics;i_z++)
			   {
				   temp3+=temp[i_z]*Math.log((1-lambda_temporal2[i_d])*topics_given_documents2[i_z][i_d]*keywords_given_topics2[i_k][i_z]);
				  // temp3+=temp1[i_z]*Math.log((lambda_temporal2[i_d])*topics_given_timeslice2[i_z][i_t]*keywords_given_topics2[i_k][i_z]);  		   
			   
			   }
			   for(int i_z=0;i_z<context_number_of_topics;i_z++)
			   {
				  // temp3+=temp[i_z]*Math.log((1-lambda_temporal2[i_d])*topics_given_documents2[i_z][i_d]*keywords_given_topics2[i_k][i_z]);
				   temp3+=temp1[i_z]*Math.log((lambda_temporal2[i_d])*topics_given_timeslice2[i_z][i_t]*keywords_given_context_topics2[i_k][i_z]);  		   
			   
			   }
			   sum=sum+it.number*temp3;
			}	
			
		}
		
		return sum;
	}
	
	public double compute_regularization(double topics_given_timeslice[][])
	{
		double sum=0;
	  for(int i_t=1;i_t<number_of_timeslices;i_t++)
	  {
		  for(int i_z=0;i_z<context_number_of_topics;i_z++)
		  {
			  sum=sum+(topics_given_timeslice[i_z][i_t]-topics_given_timeslice[i_z][i_t-1])*(topics_given_timeslice[i_z][i_t]-topics_given_timeslice[i_z][i_t-1]);
			  
		  }
	  }
	 
	  return sum;
	}
	
	public void estimate_lambda_next(){
		for(int i_d=0;i_d<number_of_documents;i_d++){
			lambda_temporal_next[i_d]=estimate_lambda_temporal[i_d]/
				(estimate_lambda_temporal[i_d]+estimate_lambda_stable[i_d]);
		}
	}
	
	//E-M algorithm including time smoothing, which enhance the original E_M_step2 algorithm using time smoothing
	public void E_step()
	{  
		
		assigning_latent_variable_zero();
		for(int i_d:user_item_graph.keySet())
		{
			for(Item it:user_item_graph.get(i_d))
			{  
				int i_k=it.item_id;
				int i_t = it.slice_id;
				double denominator=0;
				if(i_t>=0)
				{
				for(int i_z=0;i_z<number_of_topics;i_z++)
				{   
					double temp=0;
					temp=(1-lambda_temporal[i_d])*
					topics_given_documents[i_z][i_d]*
					keywords_given_topics[i_k][i_z];
					
					it.interest_topic[i_z]=temp;
					
					
					denominator+=temp;
				}

				for(int i_z=0;i_z<context_number_of_topics;i_z++)
				{   
					double temp=0;
					
					temp=lambda_temporal[i_d]*
					topics_given_timeslice[i_z][i_t]*keywords_given_context_topics[i_k][i_z];
					it.fashion_topic[i_z]=temp;
					
					denominator+=temp;
				}
				for(int i_z=0;i_z<number_of_topics;i_z++)
				{
					if(denominator==0) {
						//it.fashion_topic[i_z]=0;
						it.interest_topic[i_z]=0;
						
					}
					else {
						
						//it.fashion_topic[i_z]/=denominator;
						it.interest_topic[i_z]/=denominator;
					}
				}
				for(int i_z=0;i_z<context_number_of_topics;i_z++)
				{
					if(denominator==0) {
						it.fashion_topic[i_z]=0;
						//it.interest_topic[i_z]=0;
						
					}
					else {
						
						it.fashion_topic[i_z]/=denominator;
						//it.interest_topic[i_z]/=denominator;
					}
				}
				
			}
					
			}
			
		}
		
	}
	
	public void M_step()
	{
		
		double pre_max=compute_objective_function(topics_given_timeslice,keywords_given_topics,topics_given_documents,lambda_temporal,keywords_given_context_topics,1);
		assign_zero();
		
		for(int i_d:user_item_graph.keySet())
		{
			for(Item it:user_item_graph.get(i_d))
			{  
				int i_k=it.item_id;
				//the timestamp of document
				int i_t = it.slice_id;
				if(i_t>=0)
				{
				for(int i_z=0;i_z<number_of_topics;i_z++)
				{
					double estimate_tkd=it.number*
					it.interest_topic[i_z];
					
					topics_given_documents_next[i_z][i_d]+=estimate_tkd;
					keywords_given_topics_next[i_k][i_z]+=estimate_tkd;
					estimate_lambda_stable[i_d]+=estimate_tkd;
					
					
					
				}
				
				for(int i_z=0;i_z<context_number_of_topics;i_z++)
				{
					
					
					
					double estimate_bkd=it.number*
					it.fashion_topic[i_z];
					
					topics_given_timeslice_next[i_z][i_t]+=estimate_bkd;
					keywords_given_context_topics_next[i_k][i_z]+=estimate_bkd;
					estimate_lambda_temporal[i_d]+=estimate_bkd;
				}
				
				
				}		
			}	
		}
		
		
		
		matrix_function.normalize_smooth(topics_given_documents_next);
		matrix_function.normalize_smooth(topics_given_timeslice_next);
		matrix_function.normalize_smooth(keywords_given_topics_next);
		matrix_function.normalize_smooth(keywords_given_context_topics_next);
		estimate_lambda_next();
		if(lamda>0)
		refine_M_step(pre_max,1);
		else
		{
			normalize_and_copy(); 
		}
	}
	
	
	
	
	
	
	public void iteration(int number,boolean ispeedup)
	{   
		//initialize(ispeedup);
		if(ispeedup)
		{
			for(int i=0;i<number;i++)
			{  
				
				E_step();
				M_step();
				System.out.println("iteration "+i+" complete!");
				
			}
				
			
		}
		else
		{
			for(int i=0;i<number;i++)
			{
				E_M_step(i);
				System.out.println("iteration "+i+" complete!");
				
			}
		}
	}
}
